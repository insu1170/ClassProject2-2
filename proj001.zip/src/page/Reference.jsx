import React from "react";
import SubImg from "../component/SubImg";
import Slogan from "../component/Slogan";
import "../Style/Subpage.css";
function Reference() {
  return (
    <div>
      <Slogan></Slogan>
      <SubImg src="/img/allps.png" text="ALPS란?"></SubImg>
      <div style={{ display: "flex" }}>
      <div className="subMenu"><div className="menu">메뉴</div> <div className="process">처리과정</div> <div className="manage">관리</div> <div className="news">관련 기사</div> </div>
        <div className="subText">
          <h1>참고할 사이트-사이트맵</h1>
              <br/>
          <h3>참고한 사이트는 다음과 같습니다.</h3><br/>
          <div>
            <li>도쿄전력 https://www.tepco.co.jp/en/hd/responsibility/index-e.html</li>
            <li>국제원자력 기구 https://www.iaea.org/</li>
            <li>KBS 후쿠시마 원전 방류 오염수 이슈 탭 https://news.kbs.co.kr/news/listIssue.html?icd=19649#1</li>
            <li>처리수 포털 사이트 https://www.tepco.co.jp/ko/decommission/progress/watertreatment/index-kr.html</li>
          </div>
        </div></div>
    </div>
  )
}
export default Reference;